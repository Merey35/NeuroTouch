package com.example.neurotouch

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast

class OverlayViewManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var cursorView: View? = null
    private var sidebarView: View? = null
    private var isSidebarVisible = false
    private var isCursorVisible = false

    private lateinit var cursorParams: WindowManager.LayoutParams

    fun show() {
        if (!android.provider.Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "Overlay permission not granted", Toast.LENGTH_SHORT).show()
            return
        }
        showSidebar()
        showCursor()
    }

    private fun showSidebar() {
        if (isSidebarVisible) return
        
        val inflater = LayoutInflater.from(context)
        sidebarView = inflater.inflate(R.layout.overlay_sidebar, null)

        sidebarView?.findViewById<ImageView>(R.id.btnReset)?.setOnClickListener {
            // Send broadcast to recalibrate
            val intent = Intent("com.example.neurotouch.CALIBRATE")
            intent.setPackage(context.packageName)
            context.sendBroadcast(intent)
            Toast.makeText(context, "Looking straight? Recalibrating...", Toast.LENGTH_SHORT).show()
        }

        sidebarView?.findViewById<ImageView>(R.id.btnScrollMode)?.setOnClickListener {
            Toast.makeText(context, "Scroll mode toggled (To Be Implemented)", Toast.LENGTH_SHORT).show()
            // TODO: Implement scroll toggling state
        }

        sidebarView?.findViewById<ImageView>(R.id.btnOpenApp)?.setOnClickListener {
            val intent = Intent(context, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 200

        windowManager.addView(sidebarView, params)
        isSidebarVisible = true
    }

    private fun showCursor() {
        if (isCursorVisible) return

        val inflater = LayoutInflater.from(context)
        cursorView = inflater.inflate(R.layout.overlay_cursor, null)

        cursorParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, // Passes touch through
            PixelFormat.TRANSLUCENT
        )
        cursorParams.gravity = Gravity.TOP or Gravity.START
        cursorParams.x = 500
        cursorParams.y = 500

        windowManager.addView(cursorView, cursorParams)
        isCursorVisible = true
    }

    fun updateCursorPosition(x: Float, y: Float) {
        if (cursorView != null && isCursorVisible) {
            cursorParams.x = x.toInt()
            cursorParams.y = y.toInt()
            windowManager.updateViewLayout(cursorView, cursorParams)
        }
    }

    fun showCalibrationSuccess() {
        Toast.makeText(context, "Calibration Complete!", Toast.LENGTH_SHORT).show()
    }

    fun showClickAnimation() {
        cursorView?.findViewById<View>(R.id.cursorDot)?.let { dot ->
            dot.animate().scaleX(0.5f).scaleY(0.5f).setDuration(100).withEndAction {
                dot.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start()
            }.start()
        }
    }

    fun hide() {
        if (isSidebarVisible && sidebarView != null) {
            windowManager.removeView(sidebarView)
            isSidebarVisible = false
        }
        if (isCursorVisible && cursorView != null) {
            windowManager.removeView(cursorView)
            isCursorVisible = false
        }
    }
}
