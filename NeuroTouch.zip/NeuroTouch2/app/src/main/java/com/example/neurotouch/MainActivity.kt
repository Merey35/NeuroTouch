package com.example.neurotouch

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var tvServiceStatus: TextView

    private val requestCameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                Toast.makeText(this, "Camera Permission Granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Camera Permission is Required", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("NeuroTouchPrefs", Context.MODE_PRIVATE)

        setupPermissions()
        setupTrackingMode()
        setupSensitivity()
        setupCalibration()

        tvServiceStatus = findViewById(R.id.tvServiceStatus)
    }

    override fun onResume() {
        super.onResume()
        checkServiceStatus()
    }

    private fun setupPermissions() {
        findViewById<Button>(R.id.btnCameraPermission).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            } else {
                Toast.makeText(this, "Camera Permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay Permission already granted", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnAccessibilityPermission).setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Find NeuroTouch in the list and enable it", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupTrackingMode() {
        val rg = findViewById<RadioGroup>(R.id.rgTrackingMode)
        val rbHead = findViewById<RadioButton>(R.id.rbHeadPose)
        val rbEye = findViewById<RadioButton>(R.id.rbEyeGaze)

        val currentMode = prefs.getString("tracking_mode", "head")
        if (currentMode == "eye") rbEye.isChecked = true else rbHead.isChecked = true

        rg.setOnCheckedChangeListener { _, checkedId ->
            val mode = if (checkedId == R.id.rbEyeGaze) "eye" else "head"
            prefs.edit().putString("tracking_mode", mode).apply()
        }
    }

    private fun setupSensitivity() {
        val slider = findViewById<Slider>(R.id.sliderSensitivity)
        val currentLevel = prefs.getFloat("sensitivity", 3.0f)
        slider.value = currentLevel

        slider.addOnChangeListener { _, value, _ ->
            prefs.edit().putFloat("sensitivity", value).apply()
        }
    }

    private fun setupCalibration() {
        findViewById<Button>(R.id.btnCalibrate).setOnClickListener {
            if (isAccessibilityServiceEnabled()) {
                val intent = Intent("com.example.neurotouch.CALIBRATE")
                intent.setPackage(packageName)
                sendBroadcast(intent)
                Toast.makeText(this, "Calibration requested! Look straight at the camera.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Please enable the Accessibility Service first.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkServiceStatus() {
        if (isAccessibilityServiceEnabled()) {
            tvServiceStatus.text = "Service Status: Running"
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark))
        } else {
            tvServiceStatus.text = "Service Status: Not Enabled"
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        var enabled = false
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        for (service in enabledServices) {
            if (service.resolveInfo.serviceInfo.packageName == packageName) {
                enabled = true
                break
            }
        }
        return enabled
    }
}
