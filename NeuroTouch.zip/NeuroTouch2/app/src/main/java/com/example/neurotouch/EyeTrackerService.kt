package com.example.neurotouch

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.WindowManager
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class EyeTrackerService : AccessibilityService(), LifecycleOwner {

    private val mLifecycleRegistry = LifecycleRegistry(this)
    private lateinit var cameraExecutor: ExecutorService
    private var overlayManager: OverlayViewManager? = null

    private lateinit var prefs: SharedPreferences

    // Calibration Baselines
    private var baselineHeadX = 0f
    private var baselineHeadY = 0f
    private var isCalibrated = false
    
    // Smooth Cursor
    private var currentCursorX = 0f
    private var currentCursorY = 0f
    
    // Screen bounds
    private var screenWidth = 0
    private var screenHeight = 0

    // Blink threshold variables
    private var blinkFrames = 0
    private var lastClickTime = 0L

    private val calibrateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.neurotouch.CALIBRATE") {
                isCalibrated = false // reset flag to capture next frame
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        cameraExecutor = Executors.newSingleThreadExecutor()
        prefs = getSharedPreferences("NeuroTouchPrefs", Context.MODE_PRIVATE)

        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        
        currentCursorX = screenWidth / 2f
        currentCursorY = screenHeight / 2f

        registerReceiver(calibrateReceiver, IntentFilter("com.example.neurotouch.CALIBRATE"), RECEIVER_EXPORTED)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        
        overlayManager = OverlayViewManager(this)
        overlayManager?.show()
        
        startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, { imageProxy ->
                        processImageProxy(imageProxy)
                    })
                }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, imageAnalyzer
                )
            } catch (exc: Exception) {
                Log.e("EyeTracker", "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun processImageProxy(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            
            val options = FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .build()
                
            val detector = FaceDetection.getClient(options)
            
            detector.process(image)
                .addOnSuccessListener { faces ->
                    if (faces.isNotEmpty()) {
                        processFace(faces[0])
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("EyeTracker", "Face detection failed", e)
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }

    private fun processFace(face: Face) {
        // Calibration
        if (!isCalibrated) {
            baselineHeadX = face.headEulerAngleY // Y is left/right turn
            baselineHeadY = face.headEulerAngleX // X is up/down tilt
            isCalibrated = true
            Handler(Looper.getMainLooper()).post {
                overlayManager?.showCalibrationSuccess()
            }
            return
        }

        // Get settings
        val sensitivity = prefs.getFloat("sensitivity", 3.0f) * 10f
        
        // Calculate deltas
        val deltaX = face.headEulerAngleY - baselineHeadX
        val deltaY = face.headEulerAngleX - baselineHeadY
        
        // Update Cursor position
        currentCursorX += deltaX * sensitivity
        currentCursorY += deltaY * sensitivity

        // Bound checking
        currentCursorX = max(0f, min(currentCursorX, screenWidth.toFloat()))
        currentCursorY = max(0f, min(currentCursorY, screenHeight.toFloat()))
        
        Handler(Looper.getMainLooper()).post {
            overlayManager?.updateCursorPosition(currentCursorX, currentCursorY)
        }

        // Blink Detection
        val leftOpen = face.leftEyeOpenProbability ?: 1.0f
        val rightOpen = face.rightEyeOpenProbability ?: 1.0f
        
        if (leftOpen < 0.2f && rightOpen < 0.2f) {
            blinkFrames++
            if (blinkFrames > 5) { // Roughly 200-300ms depending on framerate
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastClickTime > 1000) { // Cooldown
                    performClick(currentCursorX, currentCursorY)
                    lastClickTime = currentTime
                    blinkFrames = 0
                }
            }
        } else {
            blinkFrames = 0
        }
    }

    private fun performClick(x: Float, y: Float) {
        Handler(Looper.getMainLooper()).post {
            overlayManager?.showClickAnimation()
        }
        val path = Path()
        path.moveTo(x, y)
        val builder = GestureDescription.Builder()
        val gesture = GestureDescription.StrokeDescription(path, 0, 50)
        builder.addStroke(gesture)
        dispatchGesture(builder.build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used, we dispatch gestures, not react to UI
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        cameraExecutor.shutdown()
        overlayManager?.hide()
        unregisterReceiver(calibrateReceiver)
    }

    override val lifecycle: Lifecycle
        get() = mLifecycleRegistry
}
